import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToMany,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import { User } from './User.entity';
import { Message } from './Message.entity';
import { ChatUnreadCount } from './ChatUnreadCount.entity';
import { Bot } from './Bot.entity';

export enum ChatType {
  PRIVATE = 'private',
  GROUP = 'group',
  SUPERGROUP = 'supergroup',
  CHANNEL = 'channel',
}

@Entity('chats')
export class Chat {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'bigint' })
  @Index()
  telegramChatId: number;

  @ManyToOne(() => Bot, (bot) => bot.chats)
  @JoinColumn({ name: 'bot_id' })
  @Index()
  bot: Bot;

  @Column({ name: 'bot_id' })
  botId: string;

  @Column({
    type: 'enum',
    enum: ChatType,
    default: ChatType.PRIVATE,
  })
  chatType: ChatType;

  @Column({ type: 'varchar', length: 255, nullable: true })
  title: string | null;

  @ManyToOne(() => User, (user) => user.chats)
  @JoinColumn({ name: 'user_id' })
  @Index()
  user: User;

  @Column({ name: 'user_id' })
  userId: string;

  @ManyToOne(() => Message, { nullable: true })
  @JoinColumn({ name: 'last_message_id' })
  lastMessage: Message | null;

  @Column({ name: 'last_message_id', nullable: true })
  lastMessageId: string | null;

  @Column({ type: 'timestamp', nullable: true })
  lastMessageAt: Date | null;

  @Column({ type: 'boolean', default: false })
  isBotBlocked: boolean;

  @OneToMany(() => Message, (message) => message.chat, {
    cascade: true,
    onDelete: 'CASCADE',
  })
  messages: Message[];

  @OneToMany(() => ChatUnreadCount, (unreadCount) => unreadCount.chat, {
    cascade: true,
    onDelete: 'CASCADE',
  })
  unreadCounts: ChatUnreadCount[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

